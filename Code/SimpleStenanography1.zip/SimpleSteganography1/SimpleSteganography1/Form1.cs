﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SimpleSteganography
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonOpenFile_Click(object sender, EventArgs e)
        {
            OpenFile("Original");
        }

        private void buttonEncode_Click(object sender, EventArgs e)
        {
            Bitmap img = new Bitmap(OriginalFilePath.Text);

            for (int i = 0; i < img.Width; i++)   
            {
                for (int j = 0; j < img.Height; j++)
                {
                    Color pixel = img.GetPixel(i, j);
                    int digit1, digit2, digit3;
                    if (j < EnterMessage.TextLength)
                    {
                        char letter = Convert.ToChar(EnterMessage.Text.Substring(j, 1));
                        int value = Convert.ToInt32(letter);
                        digit1 = letter / 100;
                        digit2 = (letter - (digit1 * 100)) / 10;
                        digit3 = (letter - (digit1 * 100) - (digit2 * 10));

                        if (pixel.R - 9 < 0 || pixel.G - 9 < 0 || pixel.B - 9 < 0)
                        {
                            img.SetPixel(i, j, Color.FromArgb(pixel.R + digit1, pixel.G + digit2, pixel.B + digit3));
                        }
                        else
                        {
                            img.SetPixel(i, j, Color.FromArgb(pixel.R - digit1, pixel.G - digit2, pixel.B - digit3));
                        }

                        if (i == img.Width - 1 && j == img.Height -1)
                        {
                            img.SetPixel(i, j, Color.FromArgb(pixel.R, pixel.G, EnterMessage.TextLength));
                        }
                    }
                }
                
            }

            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "Image Files (*.png) | *.png";
            saveFile.InitialDirectory = @"C:\Users\erict\OneDrive\Pictures\Hack The U\Sten";

            if (saveFile.ShowDialog() == DialogResult.OK)
            {
                OriginalFilePath.Text = saveFile.FileName.ToString();
                OriginalPicutreBox.ImageLocation = OriginalFilePath.Text;

                img.Save(OriginalFilePath.Text);
            }
        }

        private void buttonDecode_Click(object sender, EventArgs e)
        {
            Bitmap img = new Bitmap(StenFilePath.Text);
            Bitmap img2 = new Bitmap(OriginalFilePath.Text);

            Color lastpixel = img.GetPixel(img.Width - 1, img.Height - 1);
            int msgLength = lastpixel.B;

            string message = "";
            for (int i = 0; i < img.Width; i++)  
            {
                for (int j = 0; j < img.Height; j++)
                {
                    if (i < 1 && j < msgLength)
                    {                       
                        Color pixelSten = img.GetPixel(i, j);
                        Color pixelOrig = img2.GetPixel(i, j);

                        int rOriginal = pixelOrig.R;
                        int gOriginal = pixelOrig.G;
                        int bOriginal = pixelOrig.B;
                        int rSten = pixelSten.R;
                        int gSten = pixelSten.G;
                        int bSten = pixelSten.B;

                        int value; 
                        if(rOriginal - 9 < 0 || gOriginal - 9 < 0 || bOriginal - 9 < 0)
                        {
                            value = (
                            ((rSten - rOriginal) * 100) +
                            ((gSten - gOriginal) * 10) +
                            (bSten - bOriginal));
                        }
                        else
                        {
                            value = (
                            ((rOriginal - rSten) * 100) +
                            ((gOriginal - gSten) * 10) +
                            (bOriginal - bSten));
                        }

                        //int value = pixel.B;
                        char c = Convert.ToChar(value);
                        string letter = System.Text.Encoding.ASCII.GetString(new byte[] { Convert.ToByte(c) });

                        message = message + letter;
                    }
                }
            }

            ReturnMessage.Text = message;
        }

        private void OpenStenFile_Click(object sender, EventArgs e)
        {
            OpenFile("Sten");
        }

        private void OpenFile(string type)
        {
            OpenFileDialog openDialog = new OpenFileDialog();
            openDialog.Filter = "Image Files (*.png) | *.png";
            if (type == "Sten")
            {
                openDialog.InitialDirectory = @"C:\Users\erict\OneDrive\Pictures\Hack The U\Sten";
            }
            else if (type == "Original")
            {
                openDialog.InitialDirectory = @"C:\Users\erict\OneDrive\Pictures\Hack The U\Poke";
            }
            if (openDialog.ShowDialog() == DialogResult.OK)
            {
                if (type == "Original")
                {
                    OriginalFilePath.Text = openDialog.FileName.ToString();
                    OriginalPicutreBox.ImageLocation = OriginalFilePath.Text;
                }
                else if (type == "Sten")
                {
                    StenFilePath.Text = openDialog.FileName.ToString();
                    StenPictureBox.ImageLocation = StenFilePath.Text;
                }
            }
        }

        private void EncryptMultiple_Click(object sender, EventArgs e)
        {
            for(int k = 1; k <= 151; k++)
            {
                FolderFinder.Text = @"C:\Users\erict\OneDrive\Pictures\Hack The U\Poke3\" + k + ".png";
                 Bitmap img = new Bitmap(FolderFinder.Text);

                for (int i = 0; i < img.Width; i++)
                {
                    for (int j = 0; j < img.Height; j++)
                    {
                        Color pixel = img.GetPixel(i, j);
                        int digit1, digit2, digit3;
                        if (j < EnterMessage.TextLength)
                        {
                            char letter = Convert.ToChar(EnterMessage.Text.Substring(j, 1));
                            int value = Convert.ToInt32(letter);
                            digit1 = letter / 100;
                            digit2 = (letter - (digit1 * 100)) / 10;
                            digit3 = (letter - (digit1 * 100) - (digit2 * 10));
                            if (pixel.R - 9 < 0 || pixel.G - 9 < 0 || pixel.B - 9 < 0)
                            {
                                img.SetPixel(i, j, Color.FromArgb(pixel.R + digit1, pixel.G + digit2, pixel.B + digit3));
                            }
                            else
                            {
                                img.SetPixel(i, j, Color.FromArgb(pixel.R - digit1, pixel.G - digit2, pixel.B - digit3));
                            }

                            if (i == img.Width - 1 && j == img.Height - 1)
                            {
                                img.SetPixel(i, j, Color.FromArgb(pixel.R, pixel.G, EnterMessage.TextLength));
                            }
                        }
                    }
                }
                FolderFinder.Text = @"C:\Users\erict\OneDrive\Pictures\Hack The U\Sten\" + k + "Sten3.png";
                img.Save(FolderFinder.Text);
            }
        }
    }
}
